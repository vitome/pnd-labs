export NETKIT_HOME=/home/angelo/opt/Kathara/bin

$NETKIT_HOME/lstart


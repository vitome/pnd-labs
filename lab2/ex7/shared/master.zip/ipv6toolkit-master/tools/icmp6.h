/*
 * Header file for the icmp6 tool
 *
 */

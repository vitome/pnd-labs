/*
 * Header file for the ni6 tool
 *
 */

#define QUERY_TIMEOUT 2
